package com.example.evaluacion0802.models

import com.example.evaluacion0802.R

var plato = listOf(
    Plato(id = 1, nombre = "Arroz Thai", desc = "Arroz mezclado con finas hierbas, carne de cerdo y de res y platano maduro", foto = R.drawable.arrozthai),
    Plato(id = 2, nombre = "Rollo California", desc = "Salmón, aguacate y queso crema", foto = R.drawable.california),
    Plato(id = 3, nombre = "Caribean Roll", desc = "Platano maduro, aguacate, salmon y queso crema", foto = R.drawable.caribean_roll),
    Plato(id = 4, nombre = "Combo Almuerzo", desc = "Rollo con langostino apanado + Gaseosa 250 ml", foto = R.drawable.comboalmuerzo),
    Plato(id = 5, nombre = "Gyozas", desc = "Masa rellena de carne cerdo al vapor", foto = R.drawable.gyozas),
    Plato(id = 6, nombre = "Langostinos", desc = "Langostino apanado con salsa de la casa", foto = R.drawable.langostinoapanado),
    Plato(id = 7, nombre = "Poke Bowl", desc = "Plato de arroz con 2 proteinas y 2 adiciones", foto = R.drawable.pokebowl),
    Plato(id = 8, nombre = "Sushi Burger", desc = "Hamburguesa con tapas de arroz rellena con salmon, aguacate y queso crema", foto = R.drawable.sushi_burger),
    Plato(id = 9, nombre = "Rollo tartar de salmón", desc = "Rollo de tartar de salmon con una capa de arroz", foto = R.drawable.tartardesalmon),
    Plato(id = 10, nombre = "Bowl de vegetales", desc = "Vegetales cocinados al vapor", foto = R.drawable.sushi),
)