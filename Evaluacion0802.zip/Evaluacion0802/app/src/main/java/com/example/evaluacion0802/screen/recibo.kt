package com.example.evaluacion0802.screen

import android.annotation.SuppressLint
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evaluacion0802.R
import com.example.evaluacion0802.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Recibo(navController: NavController){
    Scaffold (
        modifier = Modifier.padding(2.dp),
        topBar = {
            TopAppBar() {
                                Button(onClick = { navController.navigate(route = AppNav.Menu.route)}) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Menu")
                }//fin button
            }//fin topappbar
        },//fin top bar
        bottomBar = {
            BottomAppBar() {
                Button(onClick = { navController.navigate(route = AppNav.Menu.route)}) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Menu")
                }
                Spacer(modifier = Modifier.width(100.dp))
                Icon(imageVector = Icons.Default.ExitToApp, contentDescription = "salir")

            }
        }
    ){
        Body3(navController)
    }//fin Scaffold
}//fin fun inicio

@Composable
fun Body3(navController: NavController){
    Column(){
        Row() {
            Image(
                modifier = Modifier
                    .size(100.dp)
                    .border(1.dp, MaterialTheme.colors.background, CircleShape)
                    .clip(CircleShape),
                painter = painterResource(R.drawable.arrozthai),
                contentDescription = "")
            Spacer(modifier = Modifier.width(10.dp))
            var expandir by remember { mutableStateOf(false) }
            val colorFondo by animateColorAsState(
                if(expandir) MaterialTheme.colors.primary else MaterialTheme.colors.background
            )
            Column(modifier = Modifier.clickable { expandir = !expandir }) {
                Text(text = "No. Plato: 1")
                Text(text = "Nombre: Arroz Thai")
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    elevation = 2.dp,
                    color = colorFondo,
                    modifier = Modifier
                        .animateContentSize()
                        .padding(2.dp)
                ){
                    Text(text = "Descripcion: Arroz mezclado con finas hierbas, carne de cerdo y de res y platano maduro")
                }//fin del surface
            }//fin de la columna texto
        }//fin Row contenido
    }//fin Column
}//fin fun body