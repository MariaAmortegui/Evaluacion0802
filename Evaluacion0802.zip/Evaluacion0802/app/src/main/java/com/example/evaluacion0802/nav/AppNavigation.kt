package com.example.evaluacion0802.nav

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.evaluacion0802.screen.*


@Composable
fun AppNavigation(){
    val navController = rememberNavController()
    NavHost(
        navController = navController,
        startDestination = AppNav.Inicio.route) {
        composable(route = AppNav.Inicio.route) { Inicio(navController) }
        composable(route = AppNav.Menu.route) { Menu(navController) }
        composable(route = AppNav.Recibo.route) { Recibo(navController) }
    }//fin navhost
}//fin fun appnavigation