package com.example.evaluacion0802.screen

import android.annotation.SuppressLint
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.*
import androidx.navigation.NavController
import com.example.evaluacion0802.R
import com.example.evaluacion0802.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Inicio(navController: NavController){
    Scaffold (
        modifier = Modifier.padding(2.dp),
        topBar = {
            TopAppBar() {
                Spacer(modifier = Modifier.width(300.dp))
                Button(onClick = { navController.navigate(route = AppNav.Menu.route)}) {
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Menu")
                }//fin button
            }//fin topappbar
        },//fin top bar
        bottomBar = {
            BottomAppBar() {
                Button(onClick = { navController.navigate(route = AppNav.Menu.route)}) {
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Menu")
                }
                Spacer(modifier = Modifier.width(100.dp))
                Icon(imageVector = Icons.Default.ExitToApp, contentDescription = "Menu")

            }
        }
            ){
        Body(navController)
    }//fin Scaffold
}//fin fun inicio

@Composable
fun Body(navController: NavController){
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(){Text(text = "GARY SUSHI", fontSize = 40.sp)}
            Spacer(modifier = Modifier.height(13.dp))
        Row(){Text(text = "Restaurante de Sushi",fontSize = 20.sp)}
            Spacer(modifier = Modifier.height(13.dp))
        Row(){Text(text = "Carrera 4 No. 7-36",fontSize = 20.sp)}
        Spacer(modifier = Modifier.height(40.dp))
        Row() {
            Image(painter = painterResource(R.drawable.logo), contentDescription = "")
        }//fin row
        Row (){

        }
    }//fin column
}//fin fun body