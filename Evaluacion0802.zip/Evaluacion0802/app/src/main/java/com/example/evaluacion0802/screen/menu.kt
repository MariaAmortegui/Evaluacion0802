package com.example.evaluacion0802.screen

import android.annotation.SuppressLint
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evaluacion0802.models.*
import com.example.evaluacion0802.nav.AppNav

@SuppressLint("UnusedMaterialScaffoldPaddingParameter")
@Composable
fun Menu(navController: NavController){
    Scaffold (
        modifier = Modifier.padding(2.dp),
        topBar = {
            TopAppBar() {
                Button(onClick = { navController.navigate(route = AppNav.Inicio.route)}) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Inicio")
                }//fin button
                Spacer(modifier = Modifier.width(250.dp))
                Button(onClick = { navController.navigate(route = AppNav.Recibo.route)}) {
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "Recibo")
                }//fin button
            }//fin topappbar
        },//fin top bar
        bottomBar = {
            BottomAppBar() {
                Button(onClick = { navController.navigate(route = AppNav.Recibo.route)}) {
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "recibo")
                }
                Spacer(modifier = Modifier.width(80.dp))
                Button(onClick = { navController.navigate(route = AppNav.Inicio.route)}) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "inicio")
                }
                Spacer(modifier = Modifier.width(80.dp))
                Button(onClick = { navController.navigate(route = AppNav.Recibo.route)}) {
                    Icon(imageVector = Icons.Default.ArrowForward, contentDescription = "recibo")
                }
            }
        }
    ){
        Dato(plato)
    }//fin Scaffold
}//fin fun inicio

@Composable
fun Body2(id:Int,nombre:String,desc:String,foto:Int){
    Column(){
        Row() {
            Image(
                modifier = Modifier
                    .size(100.dp)
                    .border(1.dp, MaterialTheme.colors.background, CircleShape)
                    .clip(CircleShape),
                painter = painterResource(foto),
                contentDescription = "")
            Spacer(modifier = Modifier.width(10.dp))
            var expandir by remember { mutableStateOf(false) }
            val colorFondo by animateColorAsState(
                if(expandir) MaterialTheme.colors.primary else MaterialTheme.colors.background
            )
            Column(modifier = Modifier.clickable { expandir = !expandir }) {
                Text(text = "No. Plato: "+id.toString())
                Text(text = "Nombre: "+nombre)
                Surface(
                    shape = MaterialTheme.shapes.medium,
                    elevation = 2.dp,
                    color = colorFondo,
                    modifier = Modifier
                        .animateContentSize()
                        .padding(2.dp)
                ){
                    Text(text = "Descripcion: "+desc)
                }//fin del surface
            }//fin de la columna texto
        }//fin Row contenido
    }//fin Column
}//fin funcion Menu

@Composable
fun Dato(datos: List<Plato>){
    Surface(modifier = Modifier.fillMaxSize()) {
        Column() {
            LazyColumn(){
                items(datos){
                    dato -> Body2(dato.id,dato.nombre,dato.desc,dato.foto)
                }//fin items
            }//fin lazy
        }//fin column
    }//fin del surface
}//fin fun dato

