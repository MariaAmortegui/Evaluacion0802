package com.example.evaluacion0802.models

data class Plato(
    var id : Int,
    var nombre : String,
    var desc : String,
    var foto : Int
)