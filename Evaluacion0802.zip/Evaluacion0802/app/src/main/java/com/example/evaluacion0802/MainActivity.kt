package com.example.evaluacion0802

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.evaluacion0802.nav.AppNavigation
import com.example.evaluacion0802.ui.theme.Evaluacion0802Theme


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            Evaluacion0802Theme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    AppNavigation()
                }//fin surface
            }//fin tema
        }//fin content
    }//fin oncreate
}//fin clase main

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    Evaluacion0802Theme {
        AppNavigation()
    }
}