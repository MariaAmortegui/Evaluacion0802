package com.example.evaluacion0802.nav

sealed class AppNav(val route:String){
    object Inicio : AppNav(route = "inicio")
    object Menu : AppNav(route = "menu")
    object Recibo : AppNav(route = "recibo")
}
